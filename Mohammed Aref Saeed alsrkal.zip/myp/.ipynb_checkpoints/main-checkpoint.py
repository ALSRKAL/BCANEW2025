from flask import Flask, render_template, request, redirect, url_for, session
import re
import os
from flask import Flask, flash, request, redirect, url_for, render_template
from werkzeug.utils import secure_filename
import matplotlib.pyplot as plt
import numpy as np
import cv2
import matplotlib.pyplot as plt
import numpy as np
import os


from csv import writer
import pandas as pd
from flask_material import Material
import cv2
import math
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

import os

import numpy as np
import cv2
from flask import send_from_directory
import math
import joblib



app = Flask(__name__)

# Load the pre-trained model
model = joblib.load('flood.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/home')
def home1():
    return render_template('result.html')



@app.route('/upload_image', methods=['POST'])
def upload_image():
    prediction = None
    if request.method == 'POST':
        # Get form data
        state = int(request.form['State'])
        month = int(request.form['Month'])
        rainfall = float(request.form['Rainfall'])
        temperature = float(request.form['Temperature'])
        humidity = float(request.form['Humidity'])
        wind_speed = float(request.form['WindSpeed'])
        river_flow = float(request.form['RiverFlow'])
        soil_moisture = float(request.form['SoilMoisture'])

        # Create feature array for prediction
        features = np.array([[state, month, rainfall, temperature, humidity, wind_speed, river_flow, soil_moisture]])
        
        # Predict using the model
        prediction = model.predict(features)[0]

        if prediction > 14:
                warning = "Severe Flood Risk! Immediate action required."
        elif prediction > 12:
                warning = "Moderate Flood Risk. Stay alert and monitor updates."
        elif prediction > 10:
                warning = "Low Flood Risk. No immediate danger but stay prepared."
        else:
                warning = "No flood risk detected."

    # Render the template with or without prediction
    return render_template('result.html', prediction=prediction,warning=warning)
  
@app.route('/display/<filename>')
def display_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    
if __name__ =='__main__':
	app.run()
